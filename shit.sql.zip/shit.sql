-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2018 at 10:01 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shit`
--

-- --------------------------------------------------------

--
-- Table structure for table `agents`
--

CREATE TABLE `agents` (
  `agent_name` varchar(50) NOT NULL,
  `agent_id` varchar(50) NOT NULL,
  `agent_loc` varchar(50) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `prod_id` varchar(50) NOT NULL,
  `recv_add` varchar(50) NOT NULL,
  `order_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agents`
--

INSERT INTO `agents` (`agent_name`, `agent_id`, `agent_loc`, `order_id`, `prod_id`, `recv_add`, `order_status`) VALUES
('E-kart', 'ek-01', 'Bengaluru', 'gru-01', 'cam-01', 'Mangaluru', 'order received'),
('Go-Kart', 'gk-01', 'Mangaluru', 'ysh-01', 'nike-01', 'Bengaluru', 'shipped');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `recv_name` varchar(50) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `recv_add` varchar(50) NOT NULL,
  `prod_id` varchar(50) NOT NULL,
  `order_date` date NOT NULL,
  `mop` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`recv_name`, `order_id`, `recv_add`, `prod_id`, `order_date`, `mop`) VALUES
('Guru', 'gru-01', 'Mangaluru', 'nike-01', '2018-10-17', 'Cash On Delievery'),
('Yash', 'ysh-01', 'Bengaluru', 'cam-01', '2018-10-18', 'online');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `prod_id` varchar(50) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `prod_price` int(20) NOT NULL,
  `prod_rating` int(11) NOT NULL,
  `prod_avl` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`prod_id`, `prod_name`, `prod_price`, `prod_rating`, `prod_avl`) VALUES
('alex-01', 'Alexa', 15000, 10, 'yes'),
('app-02', 'Apple PC', 100000, 9, 'no'),
('cam-01', 'Nikon Camera', 25000, 9, 'yes'),
('huw-01', 'Huawai Hotspot', 3000, 7, 'yes'),
('iph-01', 'Iphonex', 45000, 9, 'no'),
('jbl-01', 'Jbl - headphones', 5000, 9, 'yes'),
('nike-01', 'nike shoe', 5000, 8, 'no'),
('titan-01', 'Titan Watch', 15000, 9, 'yes');

-- --------------------------------------------------------

--
-- Stand-in structure for view `sort`
-- (See below for the actual view)
--
CREATE TABLE `sort` (
`recv_name` varchar(50)
,`order_id` varchar(50)
,`recv_add` varchar(50)
,`prod_id` varchar(50)
,`order_date` date
,`mop` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `order_id` varchar(50) NOT NULL,
  `due_date` date NOT NULL,
  `prod_id` varchar(50) NOT NULL,
  `order_date` date NOT NULL,
  `agent_id` varchar(50) NOT NULL,
  `order_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`order_id`, `due_date`, `prod_id`, `order_date`, `agent_id`, `order_status`) VALUES
('gru-01', '2018-10-24', 'nike-01', '2018-10-17', 'ek-01', 'order received'),
('ysh-01', '2018-10-26', 'cam-01', '2018-10-18', 'gk-01', 'shipped');

-- --------------------------------------------------------

--
-- Structure for view `sort`
--
DROP TABLE IF EXISTS `sort`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sort`  AS  select `orders`.`recv_name` AS `recv_name`,`orders`.`order_id` AS `order_id`,`orders`.`recv_add` AS `recv_add`,`orders`.`prod_id` AS `prod_id`,`orders`.`order_date` AS `order_date`,`orders`.`mop` AS `mop` from `orders` where ((`orders`.`mop` = 'online') or (`orders`.`recv_add` = 'Mangaluru')) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agents`
--
ALTER TABLE `agents`
  ADD PRIMARY KEY (`order_status`) USING BTREE,
  ADD KEY `prod_id` (`prod_id`),
  ADD KEY `orders` (`order_id`,`recv_add`) USING BTREE,
  ADD KEY `agent_id` (`agent_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`,`recv_add`) USING BTREE,
  ADD KEY `prod_id` (`prod_id`),
  ADD KEY `order_date` (`order_date`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`prod_id`,`prod_name`) USING BTREE;

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`due_date`),
  ADD KEY `prod_id` (`prod_id`) USING BTREE,
  ADD KEY `agents` (`order_status`) USING BTREE,
  ADD KEY `order_id` (`order_id`) USING BTREE,
  ADD KEY `agent_id` (`agent_id`),
  ADD KEY `order_date` (`order_date`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `agents`
--
ALTER TABLE `agents`
  ADD CONSTRAINT `agents_ibfk_1` FOREIGN KEY (`order_id`,`recv_add`) REFERENCES `orders` (`order_id`, `recv_add`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `agents_ibfk_2` FOREIGN KEY (`prod_id`) REFERENCES `product` (`prod_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`prod_id`) REFERENCES `product` (`prod_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `status`
--
ALTER TABLE `status`
  ADD CONSTRAINT `status_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `status_ibfk_2` FOREIGN KEY (`prod_id`) REFERENCES `product` (`prod_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `status_ibfk_3` FOREIGN KEY (`order_status`) REFERENCES `agents` (`order_status`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `status_ibfk_4` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `status_ibfk_5` FOREIGN KEY (`order_date`) REFERENCES `orders` (`order_date`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
